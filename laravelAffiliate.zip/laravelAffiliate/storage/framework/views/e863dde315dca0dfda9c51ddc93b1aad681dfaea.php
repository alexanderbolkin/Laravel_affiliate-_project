<?php $__env->startSection('header'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="<?php echo e(asset('backend/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    
<?php $__env->stopSection(); ?>
<!-- ========== Left Sidebar Start ========== -->
<?php $__env->startSection('leftsidebar'); ?>
    <div class="left side-menu">
        <div class="sidebar-inner slimscrollleft">
            <!--- Divider -->
            <div id="sidebar-menu">
                <ul>
                    <li class="menu-title">Main</li>

                <!-- <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect waves-primary"><i class="ti-home"></i><span> Dashboard </span></a>
                </li> -->

                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/summary.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 40px;" /><span> Summary</span><span class="menu-arrow"></span></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin.userguid.index')); ?>" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/userguid.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 30px;" />
                            <span> UserGuid</span><span class="menu-arrow"></span></a>
                    </li>
                    
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/userlist.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width:30px;" /><span> User List</span><span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('admin.userlist.alltime')); ?>"><span>All&nbsptime&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.today')); ?>"><span>Today&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.aweek')); ?>"><span>A&nbspweek&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.amonth')); ?>"><span>A&nbspmonth&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.country')); ?>"><span>Country&nbspUser</span><span class="menu-arrow"></span></a></li>
                        </ul>
                    </li>


                    <li>
                        <a href="<?php echo e(route('admin.notification.create')); ?>" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/bell.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 30px;" /><span> Send Notification</span> <span class="menu-arrow"></span></a>
                    </li>


                    <li class="has_sub">
                        <a href="#" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/CST.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 30px;" /><span> Referral Setting</span> <span class="menu-arrow"></span>
                        </a>
                        
                    </li>

                    <li class="has_sub">
                        <a href="<?php echo e(route('admin.passwordchange.index')); ?>" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/key.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width:35px;" /><span>Update&nbspAccount</span> <span class="menu-arrow"></span></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin.blog.index')); ?>" class="waves-effect waves-primary"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/userblog.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 30px;" /><span> Blog Post </span><span class="menu-arrow"></span></a>
                    </li>
                
                    <li>
                        <a href="<?php echo e(route('logout')); ?>" class="waves-effect waves-primary" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><img src="<?php echo e(asset('backend/dark/assets/images/pictures/logout.png')); ?>" class="img-responsive" alt="" style="display: inline-block;font-size: 16px;margin-left: 3px;margin-right: 15px; text-align: center; vertical-align: middle;width: 30px;" /><span> LogOut </span> <span class="menu-arrow"></span></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
        <!-- Left Sidebar End -->
        <?php $__env->stopSection(); ?>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <?php $__env->startSection('navbar'); ?>
        <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <!-- <img src="<?php echo e(asset('backend/dark/assets/images/pictures/phone.png')); ?>" class="img-responsive" alt="" style="width:20px;height:20px"/> -->
                                <h4 class="page-title" style="color:#459245">All Time User</h4><br>
                                <h4 class="page-title" style="margin-top:20px">2018/02/16 13:07:40</h4>
                                <ol class="breadcrumb float-right">
                                    <li class="breadcrumb-item"><a href="#">Altax</a></li>
                                    <li class="breadcrumb-item"><a href="#">UserList</a></li>
                                </ol>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                <?php $__env->stopSection(); ?>

                <?php $__env->startSection('content'); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card-box table-responsive">
                            <h4 class="m-t-0 header-title"><b>Top 1000</b></h4>
                            <p class="text-muted font-13 m-b-30">
                               
                            </p>

                            <table id="datatable" class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>UserName</th>
                                    <th>UserID</th>
                                    <th>All Time</th>
                                    <th>Referrals</th>
                                </tr>
                                </thead>

                                <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-01 14:22:55</td>
                                    <td>110000</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-02 13:42:43</td>
                                    <td>100080</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-04 11:35:00</td>
                                    <td>100060</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-05 20:30:53</td>
                                    <td>100050</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-06 02:30:33</td>
                                    <td>10000</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-07 05:32:50</td>
                                    <td>90080</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-08 02:32:00</td>
                                    <td>90070</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-09 01:32:00</td>
                                    <td>90040</td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-10 22:35:53</td>
                                    <td>90030</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-11 22:35:53</td>
                                    <td>90010</td>
                                </tr>
                                <tr>
                                    <td>11</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-12 12:32:53</td>
                                    <td>90000</td>
                                </tr>
                                <tr>
                                    <td>12</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-13 12:32:53</td>
                                    <td>80080</td>
                                </tr>
                                <tr>
                                    <td>13</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-14 22:22:53</td>
                                    <td>80070</td>
                                </tr>
                                <tr>
                                    <td>14</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-15 22:32:53</td>
                                    <td>80060</td>
                                </tr>
                                <tr>
                                    <td>15</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-16 13:32:53</td>
                                    <td>80050</td>
                                </tr>
                                <tr>
                                    <td>16</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-17 12:32:53</td>
                                    <td>80040</td>
                                </tr>
                                <tr>
                                    <td>17</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-18 10:32:53</td>
                                    <td>80030</td>
                                </tr>
                                <tr>
                                    <td>18</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-18 02:32:53</td>
                                    <td>80020</td>
                                </tr>
                                <tr>
                                    <td>19</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>80010</td>
                                </tr>
                                <tr>
                                    <td>20</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>80000</td>
                                </tr>
                                <tr>
                                    <td>21</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70090</td>
                                </tr>
                                <tr>
                                    <td>22</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70080</td>
                                </tr>
                                <tr>
                                    <td>23</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-05 22:03:53</td>
                                    <td>70070</td>
                                </tr>
                                <tr>
                                    <td>24</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70060</td>
                                </tr>
                                <tr>
                                    <td>25</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70050</td>
                                </tr>
                                <tr>
                                    <td>26</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70040</td>
                                </tr>
                                <tr>
                                    <td>27</td>
                                    <td>Accountant2</td>
                                    <td>Rosim</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70030</td>
                                </tr>
                                <tr>
                                    <td>28</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70020</td>
                                </tr>
                                <tr>
                                    <td>29</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70010</td>
                                </tr>
                                <tr>
                                    <td>30</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>7000</td>
                                </tr>
                                <tr>
                                    <td>31</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>60000</td>
                                </tr>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end row -->
      
            </div>
            <!-- end container -->
        </div>
        <!-- end content -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
     

        <!-- Required datatable js -->
        <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
        <!-- <script src="<?php echo e(asset('plugins/datatables/jszip.min.js')); ?>"></script> -->
        <script src="<?php echo e(asset('backend/plugins/datatables/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
        <!-- Responsive examples -->
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/dark/assets/js/jquery.app.js')); ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#datatable').DataTable();

                //Buttons examples
                var table = $('#datatable-buttons').DataTable({
                    lengthChange: false,
                    buttons: ['copy', 'excel', 'pdf']
                });

                table.buttons().container()
                        .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
            } );

        </script>

<?php $__env->stopSection(); ?>


    
        
<?php echo $__env->make('master.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>