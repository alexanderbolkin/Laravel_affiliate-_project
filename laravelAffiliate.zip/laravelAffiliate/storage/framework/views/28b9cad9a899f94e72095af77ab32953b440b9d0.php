<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="font-size:25px;background-color:#2f9b4a;text-align:center;color:white"><?php echo e(__('Registration')); ?></div>

                <div class="panel-body">

                    <form  class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                       <?php echo e(csrf_field()); ?>


                        <div class="form-group ">
                            <label for="fullname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Full Name')); ?></label>

                            <div class="col-md-6">
                                <input id="fullname" type="text" class="form-control<?php echo e($errors->has('fullname') ? ' is-invalid' : ''); ?>" name="fullname" value="<?php echo e(old('fullname')); ?>" required autofocus>

                                <?php if($errors->has('fullname')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('fullname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="birthday" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date of Birth')); ?></label>
                            <div class="col-md-6">
                                <input id="birthday" type="date" class="form-control<?php echo e($errors->has('birthday') ? ' is-invalid' : ''); ?>" name="birthday" value="<?php echo e(old('birthday')); ?>" required autofocus>

                                <?php if($errors->has('birthday')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('birthday')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country')); ?></label>
                            <div class="col-md-6">
                                <select id="country" type="text" class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" name="country" value="<?php echo e(old('country')); ?>" required autofocus>
                                    <option >United States of America</option>
                                    <option >Russia</option>
                                    <option >China</option>
                                    <option >France</option>
                                    <option >German</option>
                                </select>
                                <?php if($errors->has('country')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="state" class="col-md-4 col-form-label text-md-right"><?php echo e(__('State')); ?></label>

                            <div class="col-md-6">
                                <input id="state" type="text" class="form-control<?php echo e($errors->has('state') ? ' is-invalid' : ''); ?>" name="state" value="<?php echo e(old('state')); ?>" required autofocus>

                                <?php if($errors->has('state')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('state')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Address')); ?></label>

                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" value="<?php echo e(old('address')); ?>" required autofocus>

                                <?php if($errors->has('address')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('EMail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="phoneNumber" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>

                            <div class="col-md-6">
                                <input id="phoneNumber" type="text" class="form-control<?php echo e($errors->has('phoneNumber') ? ' is-invalid' : ''); ?>" name="phoneNumber" value="<?php echo e(old('phoneNumber')); ?>" required autofocus>

                                <?php if($errors->has('phoneNumber')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('phoneNumber')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group ">
                            <label for="whatsappNumber" class="col-md-4 col-form-label text-md-right">
                            Whatsapp Number</label>

                            <div class="col-md-6">
                                <input id="whatsappNumber" type="text" class="form-control<?php echo e($errors->has('whatsappNumber') ? ' is-invalid' : ''); ?>" name="whatsappNumber" value="<?php echo e(old('whatsappNumber')); ?>" required autofocus>

                                <?php if($errors->has('whatsappNumber')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('whatsappNumber')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="username" class="col-md-4 col-form-label text-md-right">
                            Username</label>

                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                                <?php if($errors->has('user_id')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 col-form-label text-md-right"></label>
                            <div class="col-md-6">
                                <button type="submit" class="form-control" style="background-color:#2f9b4a;color:white">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>