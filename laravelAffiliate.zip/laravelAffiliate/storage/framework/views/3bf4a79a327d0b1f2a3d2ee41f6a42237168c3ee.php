<?php $__env->startSection('header'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="<?php echo e(asset('backend/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    
<?php $__env->stopSection(); ?>
<!-- ========== Left Sidebar Start ========== -->
<?php $__env->startSection('leftsidebar'); ?>
    <div class="left side-menu">
        <div class="sidebar-inner slimscrollleft">
            <!--- Divider -->
            <div id="sidebar-menu">
                <ul>
                    <li class="menu-title">Main</li>

                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect waves-primary"><i class="ti-home"></i><span> Dashboard </span></a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(route('admin.notification.create')); ?>" class="waves-effect waves-primary"><i class="ti-files"></i><span> Notification</span> <span class="menu-arrow"></span></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin.blog.index')); ?>" class="waves-effect waves-primary"><i
                            class="ti-infinite"></i><span> Blogs </span><span class="menu-arrow"></span></a>
                    </li>
               
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect waves-primary"><i class="mdi mdi-account-multiple"></i><span> User List</span><span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('admin.userlist.alltime')); ?>"><span>All&nbsptime&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.today')); ?>"><span>Today&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.aweek')); ?>"><span>A&nbspweek&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.amonth')); ?>"><span>A&nbspmonth&nbspUser</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.userlist.country')); ?>"><span>Country&nbspUser</span><span class="menu-arrow"></span></a></li>
                        </ul>
                    </li>


                    <li class="has_sub">
                        <a href="<?php echo e(route('admin.passwordchange.index')); ?>" class="waves-effect waves-primary"><i class="mdi mdi-account"></i><span> Password Change </span> <span class="menu-arrow"></span></a>
                    </li>
                    
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect waves-primary"><i class="ti-money"></i>
                        <span>Bonous Control</span><span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('admin.referralBonousControl.bonousSetting')); ?>"><span>BonousSetting</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousControl.referralContestSetting')); ?>"><span>ReferContestSetting</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousControl.timeFrame')); ?>"><span>TimeFrame</span><span class="menu-arrow"></span></a></li>
                        </ul>
                    </li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect waves-primary">
                        <i class="ti-eye"></i><span> Refferal Bonous View</span><span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('admin.referralBonousView.alltime')); ?>"><span>All&nbsptime&nbspBonous</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousView.today')); ?>"><span>Today&nbspBonous</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousView.aweek')); ?>"><span>A&nbspweek&nbspBonous</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousView.amonth')); ?>"><span>A&nbspmonth&nbspBonous</span><span class="menu-arrow"></span></a></li>
                            <li><a href="<?php echo e(route('admin.referralBonousView.country')); ?>"><span>Country&nbspBonous</span><span class="menu-arrow"></span></a></li>
                        </ul>
                    </li>

                
                    <li>
                        <a href="<?php echo e(route('logout')); ?>" class="waves-effect waves-primary" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="ti-files"></i><span> LogOut </span> <span class="menu-arrow"></span></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            <div class="clearfix"></div>
            </div>
        </div>
    </div>
        <!-- Left Sidebar End -->
        <?php $__env->stopSection(); ?>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <?php $__env->startSection('navbar'); ?>
        <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <!-- <img src="<?php echo e(asset('backend/dark/assets/images/pictures/phone.png')); ?>" class="img-responsive" alt="" style="width:20px;height:20px"/> -->
                                <h4 class="page-title" style="color:#459245">All Time Bonous</h4><br>
                                <h4 class="page-title" style="margin-top:20px">2018/02/16 13:07:40</h4>
                                <ol class="breadcrumb float-right">
                                    <li class="breadcrumb-item"><a href="#">Altax</a></li>
                                    <li class="breadcrumb-item"><a href="#">UserList</a></li>
                                </ol>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                <?php $__env->stopSection(); ?>

                <?php $__env->startSection('content'); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card-box table-responsive">
                            <h4 class="m-t-0 header-title"><b>Top 1000</b></h4>
                            <p class="text-muted font-13 m-b-30">
                               
                            </p>

                            <table id="datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>UserName</th>
                                        <th>UserID</th>
                                        <th>All Time</th>
                                        <th>Referrals</th>
                                        <th>Bonous</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-01 14:22:55</td>
                                    <td>110000</td>
                                    <td>5000$</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-02 13:42:43</td>
                                    <td>100080</td>
                                    <td>4980$</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-04 11:35:00</td>
                                    <td>100060</td>
                                    <td>4900$</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-05 20:30:53</td>
                                    <td>100050</td>
                                    <td>4850$</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-06 02:30:33</td>
                                    <td>10000</td>
                                    <td>4800$</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-07 05:32:50</td>
                                    <td>90080</td>
                                    <td>4750$</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-08 02:32:00</td>
                                    <td>90070</td>
                                    <td>4700$</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-09 01:32:00</td>
                                    <td>90040</td>
                                    <td>4600$</td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-10 22:35:53</td>
                                    <td>90030</td>
                                    <td>4550$</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-11 22:35:53</td>
                                    <td>90010</td>
                                    <td>4500$</td>
                                </tr>
                                <tr>
                                    <td>11</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-12 12:32:53</td>
                                    <td>90000</td>
                                    <td>4450$</td>
                                </tr>
                                <tr>
                                    <td>12</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-13 12:32:53</td>
                                    <td>80080</td>
                                    <td>4400$</td>
                                </tr>
                                <tr>
                                    <td>13</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-14 22:22:53</td>
                                    <td>80070</td>
                                    <td>4350$</td>
                                </tr>
                                <tr>
                                    <td>14</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-15 22:32:53</td>
                                    <td>80060</td>
                                    <td>4300$</td>
                                </tr>
                                <tr>
                                    <td>15</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-16 13:32:53</td>
                                    <td>80050</td>
                                    <td>4250$</td>
                                </tr>
                                <tr>
                                    <td>16</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-17 12:32:53</td>
                                    <td>80040</td>
                                    <td>4200$</td>
                                </tr>
                                <tr>
                                    <td>17</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-18 10:32:53</td>
                                    <td>80030</td>
                                    <td>4150$</td>
                                </tr>
                                <tr>
                                    <td>18</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-18 02:32:53</td>
                                    <td>80020</td>
                                    <td>4100$</td>
                                </tr>
                                <tr>
                                    <td>19</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>80010</td>
                                    <td>4000$</td>
                                </tr>
                                <tr>
                                    <td>20</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>80000</td>
                                    <td>3900$</td>
                                </tr>
                                <tr>
                                    <td>21</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-04 02:32:53</td>
                                    <td>tom</td>
                                    <td>70090</td>
                                    <td>3800$</td>
                                </tr>
                                <tr>
                                    <td>22</td>
                                    <td>SArchitect33</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-03 02:32:53</td>
                                    <td>sunny</td>
                                    <td>70080</td>
                                    <td>3700$</td>
                                </tr>
                                <tr>
                                    <td>23</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>2018-03-02 02:32:53</td>
                                    <td>Risan</td>
                                    <td>70070</td>
                                    <td>3600$</td>
                                </tr>
                                <tr>
                                    <td>24</td>
                                    <td>SAchitect332</td>
                                    <td>Edinburgh1er</td>
                                    <td>2018-03-01 02:32:53</td>
                                    <td>Risan</td>
                                    <td>3560</td>
                                    <td>3400$</td>
                                </tr>
                                <tr>
                                    <td>25</td>
                                    <td>Accountant</td>
                                    <td>sTokyon12</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>gisan</td>
                                    <td>70050</td>
                                    <td>3300$</td>
                                </tr>
                                <tr>
                                    <td>26</td>
                                    <td>Samsongnail</td>
                                    <td>Edinburgh156</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>Polsan</td>
                                    <td>3100</td>
                                    <td>3100$</td>
                                </tr>
                                <tr>
                                    <td>27</td>
                                    <td>Accountant2</td>
                                    <td>Ruis</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70030</td>
                                    <td>3050</td>
                                    <td>3000$</td>
                                </tr>
                                <tr>
                                    <td>28</td>
                                    <td>hArchitect33er</td>
                                    <td>Edinburgh1</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>Yasan</td>
                                    <td>70020</td>
                                    <td>2500$</td>
                                </tr>
                                <tr>
                                    <td>29</td>
                                    <td>Accountant2</td>
                                    <td>Tokyon12</td>
                                    <td>Rola</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>70010</td>
                                    
                                    <td>2250$</td>
                                </tr>
                                <tr>
                                    <td>30</td>
                                    <td>Developer</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>oxsan</td>
                                    <td>7000</td>
                                    <td>2000$</td>
                                </tr>
                                <tr>
                                    <td>31</td>
                                    <td>DeveloperAngular</td>
                                    <td>SanFrancisco123</td>
                                    <td>2018-03-05 02:32:53</td>
                                    <td>60000</td>
                                    <td>1500$</td>
                                </tr>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end row -->
      
            </div>
            <!-- end container -->
        </div>
        <!-- end content -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
     

        <!-- Required datatable js -->
        <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
        <!-- <script src="<?php echo e(asset('plugins/datatables/jszip.min.js')); ?>"></script> -->
        <script src="<?php echo e(asset('backend/plugins/datatables/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
        <!-- Responsive examples -->
        <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

        <script type="text/javascript">
            $(document).ready(function() {
                $('#datatable').DataTable();

                //Buttons examples
                var table = $('#datatable-buttons').DataTable({
                    lengthChange: false,
                    buttons: ['copy', 'excel', 'pdf']
                });

                table.buttons().container()
                        .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
            } );

        </script>

<?php $__env->stopSection(); ?>


    
        
<?php echo $__env->make('master.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>