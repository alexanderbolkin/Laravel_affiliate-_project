<?php

namespace App\Http\Controllers;
use App\User;
use Auth;
use App\Models\Post;
use App\Models\ReferralProgram;
use Illuminate\Http\Request;
use Session;

class ReferralRelationshipController extends Controller
{
    //
}
