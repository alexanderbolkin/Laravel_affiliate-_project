<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class ReferralProgramController extends Controller
{
    

}
